<?php

$host = "127.0.0.1";
$user = "root";
$pass = "";
$database = "saetec";

$con = mysqli_connect($host, $user, $pass, $database) or die
('Unable to connect to database');

?>