# SAETEC
Sistema de Agendamentos da Etec ***(Saetec)***
## TCC
> Projeto componente de Trabalho de Conclusão de Curso (TCC) pela Etec Sylvio de Mattos Carvalho - Informática para Internet
###### Projeto realizado por
- Murilo Augusto de Arruda ***(Programmer/Back-end)***
- Igor Gabriel da Silva ***(Programmer/Front-end)***
- Luiz Gustavo Pereira dos Santos ***(Tester/Reports)***

###### Estágio de desenvolvimento
 * **14/08/2019** - **13/11/2019**
 ###### Finalização
 * Concluído em: **14/11/2019**

 